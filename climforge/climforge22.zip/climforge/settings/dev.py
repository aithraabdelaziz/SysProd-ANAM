from .base import *

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = "django-insecure-s!q(iv&-_9p_23vma$o*br1h)4ycfj50u(5i7lukbew*3vdqc)"

# SECURITY WARNING: define the correct hosts in production!
ALLOWED_HOSTS = ["*"]

# EMAIL_BACKEND = "django.core.mail.backends.console.EmailBackend"
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = 'anam.meteo@gmail.com'
EMAIL_HOST_PASSWORD = 'kedg mzai tkhr fjlk'
DEFAULT_FROM_EMAIL = EMAIL_HOST_USER #'ANAM <anaslcnm.meteo@gmail.com>'

try:
    from .local import *
except ImportError:
    pass
